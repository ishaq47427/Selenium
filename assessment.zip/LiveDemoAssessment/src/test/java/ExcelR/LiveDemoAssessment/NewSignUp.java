package ExcelR.LiveDemoAssessment;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class NewSignUp {

	public static void main(String[] args) throws IOException, InterruptedException {
		// TODO Auto-generated method stub
		WebDriverManager.firefoxdriver().setup();
		WebDriver driver = new FirefoxDriver();
		driver.get("https://app.forestadmin.com/Live%20Demo/Production/Operations/data/806052/index");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

		FileInputStream fl = new FileInputStream(
				"C:\\Users\\ishaq\\eclipse-workspace\\LiveDemoAssessment\\data.properties");
		Properties p = new Properties();
		p.load(fl);

		WebElement sign = driver.findElement(By.xpath(p.getProperty("NewSignUp")));

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", sign);

		WebElement add = driver.findElement(By.xpath(p.getProperty("Add")));
		add.click();
		WebElement discard = driver.findElement(By.xpath(p.getProperty("Discard")));
		discard.click();
		WebElement NewDrpDwn = driver.findElement(By.xpath(p.getProperty("NewFltr")));
		NewDrpDwn.click();
		WebElement pFltr = driver.findElement(By.xpath(p.getProperty("NewFltrList")));
		pFltr.click();
		
		Actions NewAct = new Actions(driver);
		WebElement sltDrpDwn = driver.findElement(By.xpath(p.getProperty("ListAdd")));
		NewAct.moveToElement(sltDrpDwn).click().perform();
		WebElement discard1 = driver.findElement(By.xpath(p.getProperty("Discard")));
		discard1.click();
		WebElement editBtn = driver.findElement(By.xpath(p.getProperty("EditBtn")));
		js.executeScript("arguments[0].click();", editBtn);
		 WebElement columnsEdit = driver.findElement(By.xpath(p.getProperty("ClnmEdit")));
		 js.executeScript("arguments[0].click();", columnsEdit);
		  Thread.sleep(2000);
	}

}
