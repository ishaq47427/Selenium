package Assignemnt_set_1;

public class main_class2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Parent parentObj = new Parent();
	        Child childObj = new Child();

	        // calling method of parent class by object of parent class
	        parentObj.display();

	        // calling method of child class by object of child class
	        childObj.display_child();

	        // calling method of parent class by object of child class
	        childObj.display_child();
	}

}
