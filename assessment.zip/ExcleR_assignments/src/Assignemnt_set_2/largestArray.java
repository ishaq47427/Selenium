package Assignemnt_set_2;

public class largestArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] numbers = { 4, 3, 8, 1, 9, 6, 7, 2 };

		int largest = Integer.MIN_VALUE;
		int secondLargest = Integer.MIN_VALUE;

		for (int i = 0; i < numbers.length; i++) {
			if (numbers[i] > largest) {
				secondLargest = largest;
				largest = numbers[i];
			} else if (numbers[i] > secondLargest) {
				secondLargest = numbers[i];
			}
		}

		System.out.println("Largest number: " + largest);
		System.out.println("Second largest number: " + secondLargest);
	}

}
