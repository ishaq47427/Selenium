package ExcelR.LiveDemoAssessment;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.List;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Orders {

	public static void main(String[] args) throws IOException, InterruptedException {
		// TODO Auto-generated method stub
		WebDriverManager.firefoxdriver().setup();
		WebDriver driver = new FirefoxDriver();
		driver.get("https://app.forestadmin.com/Live%20Demo/Production/Operations/data/806052/index");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

		FileInputStream fl = new FileInputStream(
				"C:\\Users\\ishaq\\eclipse-workspace\\LiveDemoAssessment\\data.properties");
		Properties p = new Properties();
		p.load(fl);
		
		WebElement orders = driver.findElement(By.xpath(p.getProperty("Orders")));
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", orders);
		Thread.sleep(10000);
		WebElement addOrder = driver.findElement(By.xpath(p.getProperty("AddOrder")));
		addOrder.click();
		WebElement prdclick = driver.findElement(By.xpath(p.getProperty("PrdList")));
		prdclick.click();
		Actions Ordact =  new Actions(driver);
		

		WebElement list = driver.findElement(By.xpath(p.getProperty("Prd1")));
		Ordact.moveToElement(list).click().perform();

		WebElement newAdd = driver.findElement(By.xpath(p.getProperty("CreateAdd")));
		newAdd.click();
		WebElement cancle = driver.findElement(By.xpath(p.getProperty("AddCancle")));
		cancle.click();
		WebElement dateopt = driver.findElement(By.xpath(p.getProperty("DatePic")));
		//dateopt.click();
		js.executeScript("arguments[0].click();", dateopt);
		
	}

}
