package Google.ExcelR.TestNG;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class Assertion {
	@Test
public void AssertionsEx(){
	SoftAssert sft = new SoftAssert();
	sft.assertTrue(false);
	System.out.println("soft method was exxecuted");
}
	@Test
	public void hardAssert() {
	//Assert.assertTrue(false);
	Assert.assertTrue(true);
	System.out.println("hard method is executed");
		
		
	}
}
