//1.	Calculator Program in Java
package assigments;

public class Calculator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 6;
		double b = 9.5;

		System.out.println("the addition of 2 numbers " + (a + b));
		System.out.println("the substrate of 2 numbers " + (a - b));
		System.out.println("the multiplication of 2 numbers " + (a * b));
		System.out.println("the division of 2 numbers " + (a / b));
		System.out.println("the modulus of 2 numbers " + (a % b));
	}

}
