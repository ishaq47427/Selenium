package Google.ExcelR;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class CheckBox {

	public static void main(String[] args) throws Exception {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();

		driver.get("https://demo.guru99.com/test/radio.html");
		driver.manage().window().maximize();
		// TODO Auto-generated method stub

		WebElement checkBox = driver.findElement(By.xpath("//input[@id=\"vfb-6-0\"]"));
		checkBox.click();
		
	}

}
