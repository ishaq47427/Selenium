package Assignemnt_set_2;

public class NegPosZeroCheck {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num = -3;

		if (num > 0) {
			System.out.printf("%d is positive.", num);
		} else if (num < 0) {
			System.out.printf("%d is negative.", num);
		} else {
			System.out.printf("%d is zero.", num);
		}
	}

}
