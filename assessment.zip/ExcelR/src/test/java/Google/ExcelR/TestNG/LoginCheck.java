package Google.ExcelR.TestNG;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

import org.testng.annotations.BeforeMethod;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;

public class LoginCheck {
	WebDriver driver;
  @Test
  public void Test() {
	  WebElement email = driver.findElement(By.id("email"));
	  email.sendKeys("123@gmail.com");
	  WebElement pass = driver.findElement(By.id("pass"));
	  pass.sendKeys("ishaq");
	  WebElement logIn = driver.findElement(By.id("u_0_9_HA"));
	  logIn.click();
  }
  @BeforeMethod
  public void BrowserSetUP() {
	  WebDriverManager.chromedriver().setup();
		 driver = new ChromeDriver();

			driver.get("https://www.facebook.com/");
	  }
  

  @AfterMethod
  public void CloseWindow() {
  }

}
