package Assignemnt_set_2;

public class sumOfNaturalNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int num = 5, sum = 0;

		for (int i = 1; i <= num; i++) {
			sum = sum + i;
		}

		System.out.println("Sum of first " + num + " natural numbers " + sum);

	}

}
