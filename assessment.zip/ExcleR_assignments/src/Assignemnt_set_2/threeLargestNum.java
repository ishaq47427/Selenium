package Assignemnt_set_2;

public class threeLargestNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num1 = 4, num2 = 6, num3 = 8, largest;

		largest = num1;

		if (num2 > largest) {
			largest = num2;
		}

		if (num3 > largest) {
			largest = num3;
		}
		System.out.println("The largest number is. " + largest);
	}

}
