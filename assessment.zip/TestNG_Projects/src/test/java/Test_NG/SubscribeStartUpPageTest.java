package Test_NG;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

import org.testng.annotations.BeforeClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;

public class SubscribeStartUpPageTest {
	WebDriver driver1;
  @Test
  public void f() {
	  WebElement checkBox = driver1.findElement(By.xpath("//input[@id=\"corporate\"]"));
	  checkBox.click();
	 
  }
  
  @BeforeClass
  public void opneLink() {
	  WebDriverManager.chromedriver().setup();
		driver1 = new ChromeDriver();
		driver1.get("https://phptravels.com/pricing");
		  driver1.findElement(By.linkText("SUBSCRIBE")).click();
  }

  @AfterClass
  public void closeLink() {
  }

}
