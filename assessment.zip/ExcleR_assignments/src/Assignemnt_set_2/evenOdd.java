package Assignemnt_set_2;

public class evenOdd {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num = 23;

		if (num % 2 == 0) {
			System.out.printf("%d is even.", num);
		} else {
			System.out.printf("%d is odd.", num);
		}
	}

}
