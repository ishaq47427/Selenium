package Google.ExcelR;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class DropDown {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://demo.guru99.com/test/newtours/register.php");
		
		driver.findElement(By.name("firstName")).sendKeys("ishaq");
		driver.findElement(By.name("lastName")).sendKeys("I");
		driver.findElement(By.name("phone")).sendKeys("1231234356");
		driver.findElement(By.id("userName")).sendKeys("1231234356@gmail.com");
		
		WebElement dropDown = driver.findElement(By.name("country"));
		Select country = new Select(dropDown);
		country.selectByValue("INDIA");
		country.selectByIndex(91);
		country.selectByVisibleText("RUSSIA");
		

	}

}
