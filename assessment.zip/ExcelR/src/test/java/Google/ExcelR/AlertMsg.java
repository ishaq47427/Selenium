package Google.ExcelR;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class AlertMsg {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();

		driver.get("https://demoqa.com/alerts");

		WebElement simpleAlert = driver.findElement(By.id("alertButton"));
		simpleAlert.click();

		Alert alert1 = driver.switchTo().alert();
		alert1.accept();

		WebElement confirm = driver.findElement(By.id("confirmButton"));
		confirm.click();
		Alert confirmAlt = driver.switchTo().alert();
		confirmAlt.dismiss();
		confirmAlt.accept();
		
		WebElement prompt = driver.findElement(By.id("promtButton"));
		prompt.click();
		Alert promptAlt = driver.switchTo().alert();
		promptAlt.sendKeys("ishaq");
		promptAlt.accept();

	}

}
