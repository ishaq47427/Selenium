package Assignemnt_set_2;

public class SumAndAvgOfArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arr = { 1, 23, 3, 65, 62 };
		int n = 2, sum = 0;
		int average;

		for (int i = 0; i < n; i++) {

			sum = sum + arr[i];
		}

		average =  sum / n;

		System.out.println("The sum of array elements is " + sum);
		System.out.println("The average of array elements is " + average);
	}

}
