package assessment;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class emp_crud {
	static Scanner scanner = new Scanner(System.in);

	public static void addemp() {
		System.out.println("enter employee name");
		String addemp = scanner.next();
		System.out.println("enter employee city");
		String city = scanner.next();
		System.out.println("enter employee DOB");
		String dob = scanner.next();
		System.out.println("enter employee dept");
		String dept = scanner.next();
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("assessment");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		
		EmployeeBean empBean = new EmployeeBean();
		
		empBean.setCity(city);
		empBean.setName(addemp);
		empBean.setDob(dob);
		empBean.setDept(dept);
		
		et.begin();
		em.persist(empBean);
		et.commit();	
	}

	public static void reademp() {
		
		System.out.println("enter employee Id");
		int eid = scanner.nextInt();
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("assessment");
		EntityManager em = emf.createEntityManager();
	
		
		EmployeeBean empBean = em.find(EmployeeBean.class, eid);
		
		System.out.println();
		if(empBean != null) {
			System.out.println("Employee ID \t"+empBean.getEid());
			System.out.println("employee Name:\t"+empBean.getName());
			System.out.println("employee city:\t"+empBean.getCity());
			System.out.println("employee DOB:\t"+empBean.getDob());
			System.out.println("employee dept\t"+empBean.getDept());
			System.out.println();
		}
		else {
			System.out.println("No Info Found!!");
			System.out.println();
		}
	}
	

	public static void updateemp() {
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("assessment");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		
		EmployeeBean empBean = new EmployeeBean(); 
		
		System.out.println("enter employee Id");
		int eid = scanner.nextInt();

		System.out.println("enter employee name");
		String addemp = scanner.next();

		System.out.println("enter employee city");
		String city = scanner.next();

		System.out.println("enter employee DOB");
		String dob = scanner.next();
		System.out.println("enter employee dept");
		String dept = scanner.next();
		
		et.begin();
		em.merge(empBean);
		et.commit();
	}

	public static void deleteemp() {
		System.out.println("enter employee Id");
		int eid = scanner.nextInt();
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("assessment");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		
		
		EmployeeBean empBean =  em.find(EmployeeBean.class, eid); 
		
		if(empBean != null) {
			et.begin();
			em.remove(empBean);
			et.commit();
			System.out.println();
		}
		else {
			System.out.println("No Info Found!!");
			System.out.println();
	}

}
}
