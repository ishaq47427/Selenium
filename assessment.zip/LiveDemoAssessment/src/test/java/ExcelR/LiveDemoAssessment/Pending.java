package ExcelR.LiveDemoAssessment;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Pending {

	public static void main(String[] args) throws IOException, InterruptedException  {
		// TODO Auto-generated method stub
		WebDriverManager.firefoxdriver().setup();
		WebDriver driver = new FirefoxDriver();
		driver.get("https://app.forestadmin.com/Live%20Demo/Production/Operations/data/806052/index");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

		FileInputStream fl = new FileInputStream(
				"C:\\Users\\ishaq\\eclipse-workspace\\LiveDemoAssessment\\data.properties");
		Properties p = new Properties();
		p.load(fl);
		WebElement pending = driver.findElement(By.xpath(p.getProperty("Pending")));
		//pending.click();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", pending);
		
		WebElement pFltr = driver.findElement(By.xpath(p.getProperty("pendingfltr")));
		pFltr.click();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

		WebElement fltrList = driver.findElement(By.xpath(p.getProperty("PfltrList")));
		fltrList.click();
		//WebElement fltrSrch = driver.findElement(By.xpath(p.getProperty("FltrSrch")));
		
		WebElement addFltr = driver.findElement(By.xpath(p.getProperty("SltFltr")));
		addFltr.click();
		WebElement discard = driver.findElement(By.xpath(p.getProperty("Discard")));
		discard.click();
		Thread.sleep(1000);
		WebElement pSort = driver.findElement(By.xpath(p.getProperty("Psort")));
		pSort.click();
	}

}
