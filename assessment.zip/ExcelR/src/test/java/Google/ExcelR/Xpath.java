package Google.ExcelR;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Xpath {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriverManager.edgedriver().setup();
		WebDriver driver = new EdgeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/admin/viewSystemUsers");
		
		WebElement name = driver.findElement(By.xpath("input[@name='username']"));
		name.sendKeys("Admin");
		WebElement pass = driver.findElement(By.xpath("input[@name='password']"));
		pass.sendKeys("admin123");
		
		driver.findElement(By.xpath("button[@type='submit']")).click();
		
		WebElement check = driver.findElement(By.xpath(("(//i[@class='oxd-icon bi-check oxd-checkbox-input-icon'])[2]")));
		check.click();
		
	}

}
