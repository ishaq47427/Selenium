package assigments;

public class RemoveSpace {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "good Morning";

		// Removes the white spaces using regex
		str = str.replaceAll("\\s+", "");

		System.out.println("String after removing all the white spaces : " + str);

	}

}
