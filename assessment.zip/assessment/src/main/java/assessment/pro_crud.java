package assessment;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class pro_crud {
	static Scanner scanner = new Scanner(System.in);

	public static void addpro() {
		System.out.println("enter professor name");
		String addpro = scanner.next();
		System.out.println("enter professor city");
		String city = scanner.next();
		System.out.println("enter professor DOB");
		String dob = scanner.next();
		System.out.println("enter professor dept");
		String dept = scanner.next();

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("assessment");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();

		ProfessorBean probean = new ProfessorBean();

		probean.setName(addpro);
		probean.setCity(city);
		probean.setDob(dob);
		probean.setDept(dept);

		et.begin();
		em.persist(probean);
		et.commit();
	}

	public static void readpro() {
		System.out.println("enter professor Id");
		int pid = scanner.nextInt();

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("assessment");
		EntityManager em = emf.createEntityManager();

		ProfessorBean proBean = em.find(ProfessorBean.class, pid);

		System.out.println();
		if (proBean != null) {
			System.out.println("Employee ID \t" + proBean.getPid());
			System.out.println("employee Name:\t" + proBean.getName());
			System.out.println("employee city:\t" + proBean.getCity());
			System.out.println("employee DOB:\t" + proBean.getDob());
			System.out.println("employee dept\t" + proBean.getDept());
			System.out.println();
		} else {
			System.out.println("No Info Found!!");
			System.out.println();
		}
	}

	public static void updatepro() {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("assessment");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();

		ProfessorBean proBean = new ProfessorBean();

		System.out.println("enter professor Id");
		int pid = scanner.nextInt();
		System.out.println("enter professor name");
		String addpro = scanner.next();
		System.out.println("enter professor city");
		String city = scanner.next();
		System.out.println("enter professor DOB");
		String dob = scanner.next();
		System.out.println("enter professor dept");
		String dept = scanner.next();

		et.begin();
		em.merge(proBean);
		et.commit();
	}

	public static void deletepro() {
		System.out.println("enter professor Id");
		int pid = scanner.nextInt();

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("assessment");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();

		ProfessorBean proBean = em.find(ProfessorBean.class, pid);

		if (proBean != null) {
			et.begin();
			em.remove(proBean);
			et.commit();
			System.out.println();
		} else {
			System.out.println("No Info Found!!");
			System.out.println();
		}
	}
}
