package Assignemnt_set_1;

	class Child extends Parent {
	    public void display_child() {
	        System.out.println("This is child class");
	    }
	}
