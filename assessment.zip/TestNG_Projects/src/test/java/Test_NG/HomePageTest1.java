package Test_NG;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

import org.testng.annotations.BeforeClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterClass;

public class HomePageTest1 {
	WebDriver driver1;

	@Test(priority = 0)
	public void f() {
		driver1.get("https://phptravels.com/demo/");
		// driver1.findElement(By.linkText("Sign Up")).click();
		driver1.get("https://phptravels.org/register.php");
		driver1.manage().window().maximize();
	}

	@Test(priority = 1)
	public void personalInfo() {

		driver1.findElement(By.id("inputFirstName")).sendKeys("abcd");
		driver1.findElement(By.id("inputLastName")).sendKeys("abcd");
		driver1.findElement(By.id("inputEmail")).sendKeys("abcd@gmail.com");
		driver1.findElement(By.id("inputPhone")).sendKeys("123456789");

	}

	@Test(priority = 2)
	public void billingAddress() {
		driver1.findElement(By.id("inputCompanyName")).sendKeys("ExcelR");
		driver1.findElement(By.id("inputAddress1")).sendKeys("bangalore");
		driver1.findElement(By.id("inputAddress2")).sendKeys("karnataka");
		driver1.findElement(By.id("inputCity")).sendKeys("bangalore");
		driver1.findElement(By.id("stateinput")).sendKeys("Karnataka");
		driver1.findElement(By.id("inputPostcode")).sendKeys("123645");
		WebElement countrydropDown = driver1.findElement(By.id("inputCountry"));
		Select dropDownCountry = new Select(countrydropDown);
		// dropDownEmp.selectByValue("IN");
		// dropDownEmp.selectByIndex(108);
		dropDownCountry.selectByVisibleText("India");
	}

	@Test(priority = 3)
	public void addtionalInfo() {
		driver1.findElement(By.id("customfield2")).sendKeys("12356659");
	}

	@Test(priority = 4)
	public void passwordInput() {
		driver1.findElement(By.id("inputNewPassword1")).sendKeys("02oC6QccE");
		driver1.findElement(By.id("inputNewPassword2")).sendKeys("02oC6QccE");
	}

	@BeforeClass
	public void openURL() {
		WebDriverManager.chromedriver().setup();
		driver1 = new ChromeDriver();
	}

	@AfterClass
	public void closeURL() {
	}

}
