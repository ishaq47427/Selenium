package Assignemnt_set_1;

	class Employee extends member {
	    String specialization;
	}

