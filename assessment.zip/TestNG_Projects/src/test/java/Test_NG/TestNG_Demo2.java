package Test_NG;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

import org.testng.annotations.BeforeClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterClass;

public class TestNG_Demo2 {
	WebDriver driver1;

	@Test
	public void contactDetails() {
		WebElement Name = driver1.findElement(By.id("Form_getForm_FullName"));
		Name.sendKeys("ishaq");
		WebElement Email = driver1.findElement(By.id("Form_getForm_Email"));
		Email.sendKeys("ishaq@gmail.com");
		WebElement Country = driver1.findElement(By.id("Form_getForm_Country"));
		Select countryDropDwn = new Select(Country);
		countryDropDwn.selectByIndex(96);
		WebElement noOfEmp = driver1.findElement(By.id("Form_getForm_NoOfEmployees"));
		Select empDropDown = new Select(noOfEmp);
		empDropDown.selectByValue("21 - 25");
		
		WebElement Phone = driver1.findElement(By.id("Form_getForm_Contact"));
		Phone.sendKeys("7760654936");
	}

	@BeforeClass
	public void openLink() {
		WebDriverManager.chromedriver().setup();
		driver1 = new ChromeDriver();
		driver1.get("https://www.orangehrm.com/contact-sales/");
		driver1.manage().window().maximize();
	}

	 
	@AfterClass
	public void closePage() {
		//driver1.close();
	}

}
