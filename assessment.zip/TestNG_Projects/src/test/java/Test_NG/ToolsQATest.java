package Test_NG;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

import org.testng.annotations.BeforeClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterClass;

public class ToolsQATest {
	WebDriver driver1;
  @Test
  public void f() {
	  driver1.get("https://demoqa.com/");
	  WebElement clickable = driver1.findElement(By.id(""));
      new Actions(driver1)
              .click(clickable)
              .perform();
	  }
  @BeforeClass
  public void openURL() {
	  WebDriverManager.chromedriver().setup();
		driver1 = new ChromeDriver();
  }

  @AfterClass
  public void clodeURL() {
  }

}
