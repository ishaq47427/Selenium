package Assignemnt_set_2;

import java.util.Scanner;

public class Calculator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		String operator;
		int num1, num2, result;

		System.out.print("Enter operation (add, sub, multiply, div): ");
		operator = sc.next().toString();

		System.out.print("Enter two numbers: ");
		num1 = sc.nextInt();
		num2 = sc.nextInt();

		switch (operator) {
		case "add":
			result = num1 + num2;
			System.out.printf("Addition of two umbers is " + result);
			break;

		case "sub":
			result = num1 - num2;
			System.out.printf("Subtraction of two umbers is " + result);
			break;

		case "multiply":
			result = num1 * num2;
			System.out.printf("Multiple  of two umbers is " + result);
			break;

		case "div":
			result = num1 / num2;
			System.out.printf("Division of two umbers is " + result);
			break;

		default:
			System.out.println("Invalid operator!");
			break;
		}
	}

}
