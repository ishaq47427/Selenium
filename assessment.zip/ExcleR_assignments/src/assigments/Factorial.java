//1.	Factorial Program using Recursion
package assigments;

public class Factorial {
	static int fact(int n) {
		if (n == 0)
			return 1;
		else
			return (n * fact(n - 1));

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num = 4, fact = 1;
		fact = fact(num);
		System.out.println("the factorial " + num + " is " + fact);
	}

}
