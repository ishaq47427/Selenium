package Test_NG;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

import org.testng.annotations.BeforeClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;

public class TestNG_depend {
	WebDriver driver1;

	@Test(groups = "smoke")
	public void openLink() {
		driver1.get("https://www.toolsqa.com/");
		driver1.manage().window().maximize();
	}

	@Test(priority = 1, dependsOnMethods = { "openLink" })
	public void openNav() {
		driver1.findElement(By.xpath("//a[contains(text(),'Selenium Training')]")).click();
	}

	@Test
	public void getTitle() {
		String title = driver1.getTitle();
		System.out.println(title);
	}

	@BeforeClass
	public void openURL() {
		WebDriverManager.chromedriver().setup();
		driver1 = new ChromeDriver();

	}

	@AfterClass
	public void closeURL() {

	}
}
