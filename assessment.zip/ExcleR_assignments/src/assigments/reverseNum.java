package assigments;

public class reverseNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int num = 12345;

		int reversedNumber = 0;
		while (num != 0) {
			int digit = num % 10;
			reversedNumber = reversedNumber * 10 + digit;
			num = num/ 10;
		}

		System.out.println("The reversed number is: " + reversedNumber);
	}

}
