module ExcleR_assignments {
	requires java.desktop;
}