package Google.ExcelR;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Browser_window {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		WebDriverManager.firefoxdriver().setup();
		WebDriver driver = new FirefoxDriver();
		driver.get("https://demoqa.com/browser-windows");
		String parent = driver.getWindowHandle();
		System.out.println(parent);
		WebElement tab = driver.findElement(By.id("tabButton"));
		tab.click();
		Set<String> s = driver.getWindowHandles();

		Iterator<String> I1 = s.iterator();

		while (I1.hasNext()) {
			String childWindow = I1.next();

			if (parent.equals(childWindow)) {
				driver.switchTo().window(childWindow);
				Thread.sleep(2000);
				String getText = driver.findElement(By.xpath("//h1[@id='sampleHeading']")).getText();
				
				System.out.println(getText);
				driver.close();
			}
		}
		driver.switchTo().window(parent);
	}

}
