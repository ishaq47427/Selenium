package Assignemnt_set_1;
	
	class Parent {
	    public void display() {
	        System.out.println("This is parent class");
	    }
	}

