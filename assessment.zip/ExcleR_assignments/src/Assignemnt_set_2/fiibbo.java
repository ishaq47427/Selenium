package Assignemnt_set_2;

public class fiibbo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num = 5;

		int a = 0, b = 1, c;

		System.out.print("Fibonacci Series: " + a + " " + b);

		for (int i = 3; i <= num; i++) {
			c = a + b;
			System.out.print(" " + c);
			a = b;
			b = c;
		}
	}

}
