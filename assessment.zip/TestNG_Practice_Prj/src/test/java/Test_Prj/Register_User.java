package Test_Prj;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

import org.testng.annotations.BeforeClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterClass;

public class Register_User {
	WebDriver driver;

	@BeforeClass
	public void Launch_web() {

		WebDriverManager.firefoxdriver().setup();
		driver = new FirefoxDriver();
		driver.get("https://automationexercise.com/");
		driver.manage().window().maximize();
	}

	@Test
	public void Test_Cases() {
		
		//login/signIn button
		WebElement LoginBtn = driver.findElement(By.xpath("//a[contains(text(),'Signup / Login')]"));
		LoginBtn.click();
		
		WebElement name = driver.findElement(By.xpath("//input[@type='text']"));
		name.sendKeys("ish");
		
		WebElement Email = driver.findElement(By.xpath("//form[@action='/signup']//input[@type='email']"));
		Email.sendKeys("ish1@gmail.com");
		
		WebElement SignUp = driver.findElement(By.xpath("//button[contains(text(),'Signup')]"));
		SignUp.click();
		
		WebElement Gender = driver.findElement(By.xpath("//input[@id='id_gender1']"));
		Gender.click();
		WebElement Pass = driver.findElement(By.xpath("//input[@id='password']"));
		Pass.sendKeys("123");
		
		WebElement DropDown = driver.findElement(By.xpath("//select[@id='days']"));
		Select days = new Select(DropDown);
		days.selectByValue("5");
		
		WebElement DropDown2 = driver.findElement(By.xpath("//select[@id='months']"));
		Select Months = new Select(DropDown2);
		Months.selectByVisibleText("June");
		
		WebElement DropDown3 = driver.findElement(By.xpath("//select[@id='years']"));
		Select Year = new Select(DropDown3);
		Year.selectByValue("2000");
		
		WebElement CheckBox = driver.findElement(By.xpath("//input[@id='optin']"));
		CheckBox.click();
		

		WebElement Fname = driver.findElement(By.xpath("//input[@id='first_name']"));
		Fname.sendKeys("ish");
		
		WebElement Lname = driver.findElement(By.xpath("//input[@id='last_name']"));
		Fname.sendKeys("ish");
		
		WebElement company = driver.findElement(By.xpath("//input[@id='company']"));
		company.sendKeys("google");
		
		WebElement Add = driver.findElement(By.xpath("//input[@id='address1']"));
		Add.sendKeys("Bangalore");
		
		WebElement dropDown4 = driver.findElement(By.xpath("//select[@id='country']"));
		Select country = new Select(dropDown4);
		country.selectByValue("India");
		
		WebElement city = driver.findElement(By.xpath("//input[@id='city']"));
		city.sendKeys("bangalore");
		
		WebElement PinCode = driver.findElement(By.xpath("//input[@id='zipcode']"));
		PinCode.sendKeys("560078");
		
		WebElement Ph = driver.findElement(By.xpath("//input[@id='mobile_number']"));
		Ph.sendKeys("123457890");
		
		WebElement CreateAcc = driver.findElement(By.xpath("//button[contains(text(),'Create Account')]"));
		CreateAcc.click();
		
		WebElement Continue = driver.findElement(By.xpath("//a[@class='btn btn-primary']"));
		Continue.click();
	}

		
	@AfterClass
	public void Close_browser() {
	}

}
