package Assignemnt_set_1;

class Shape {
    public void display_shape() {
        System.out.println("This is shape");
    }
}

class Rectangle extends Shape {
    public void display_rect() {
        System.out.println("This is rectangular shape");
    }
}

class Circle extends Shape {
    public void display_circle() {
        System.out.println("This is circular shape");
    }
}

class Square extends Rectangle {
    public void display_Square() {
        System.out.println("Square is a rectangle");
    }
}

