package ExcelR.LiveDemoAssessment;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Live {

	public static void main(String[] args) throws IOException, InterruptedException {

		WebDriverManager.firefoxdriver().setup();
		WebDriver driver = new FirefoxDriver();
		driver.get("https://app.forestadmin.com/Live%20Demo/Production/Operations/data/806052/index");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

		FileInputStream fl = new FileInputStream(
				"C:\\Users\\ishaq\\eclipse-workspace\\LiveDemoAssessment\\data.properties");
		Properties p = new Properties();
		p.load(fl);
		WebElement live = driver.findElement(By.xpath(p.getProperty("Live")));

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", live);
		Thread.sleep(1000);
		WebElement liveSrch = driver.findElement(By.xpath(p.getProperty("liveSrch")));
		liveSrch.sendKeys("asdfgh");

		WebElement LiveFltr = driver.findElement(By.xpath(p.getProperty("liveFltr")));
		LiveFltr.click();
		WebElement liveDrpDwn = driver.findElement(By.xpath(p.getProperty("liveDrpDwn")));
		liveDrpDwn.click();
		WebElement liveAddFltr = driver.findElement(By.xpath(p.getProperty("liveAddFltr")));
		liveAddFltr.click();
		WebElement discard = driver.findElement(By.xpath(p.getProperty("Discard")));
		discard.click();
		WebElement NewLiveAdd = driver.findElement(By.xpath(p.getProperty("liveNewAdd")));

		js.executeScript("arguments[0].click();", NewLiveAdd);

		WebElement liveNameAdd = driver.findElement(By.xpath(p.getProperty("liveNewName")));

		js.executeScript("arguments[0].value='ishaq';", liveNameAdd);
		WebElement discard1 = driver.findElement(By.xpath(p.getProperty("Discard")));
		discard1.click();

	}

}
