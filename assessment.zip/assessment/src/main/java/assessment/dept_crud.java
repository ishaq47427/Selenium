package assessment;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class dept_crud {
	static Scanner scanner = new Scanner(System.in);

	public static void adddept() {
		System.out.println("enter department name");
		String adddept = scanner.next();

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("assessment");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();

		DepartmentBean deptbean = new DepartmentBean();

		deptbean.setName(adddept);
		
		et.begin();
		em.persist(deptbean);
		et.commit();

	}

	public static void readdept() {
		System.out.println("enter department Id");
		int did = scanner.nextInt();

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("assessment");
		EntityManager em = emf.createEntityManager();
	
		
		DepartmentBean deptbean = em.find(DepartmentBean.class, did);
		
		System.out.println();
		
		if(deptbean != null) {
			System.out.println("Employee ID \t"+deptbean.getDid());
			System.out.println("employee Name:\t"+deptbean.getName());
	}
		else {
			System.out.println("No Info Found!!");
			System.out.println();
		}
	
	}
	public static void updatedept() {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("assessment");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		
		DepartmentBean deptbean = new DepartmentBean();
		
		System.out.println("enter department Id");
		int did = scanner.nextInt();

		System.out.println("enter department name");
		String adddept = scanner.next();

		et.begin();
		em.merge(deptbean);
		et.commit();
	}

	public static void deletedept() {
		System.out.println("enter department Id");
		int did = scanner.nextInt();
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("assessment");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		
		DepartmentBean deptbean = em.find(DepartmentBean.class, did);
		
		if(deptbean != null) {
			et.begin();
			em.remove(deptbean);
			et.commit();
			System.out.println();
		}
		else {
			System.out.println("No Info Found!!");
			System.out.println();
	}


	}
}
