package Test_NG;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

import org.testng.annotations.BeforeClass;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;

public class TestNG_1 {
	WebDriver driver1;
  @Test
  public void search() {
	  WebElement search = driver1.findElement(By.id("twotabsearchtextbox"));
	  search.sendKeys("iphone"+Keys.ENTER);
	  //search.click();
  }
  @BeforeClass
  public void openURL() {
	  WebDriverManager.chromedriver().setup();
	 driver1 = new ChromeDriver();

		driver1.get("https://www.amazon.in/");
  }

  @AfterClass
  public void endPage() {
	  driver1.close();
  }

}
