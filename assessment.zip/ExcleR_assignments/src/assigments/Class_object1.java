//1.Write a program to create a class and Create an Object in Java
package assigments;

//Class got created
public class Class_object1 {
	int Add(int a, int b) {
		
		return a + b;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Creating object A1
		
		Class_object1 A1  = new Class_object1();
		
		System.out.println("the addition of two numbers is " +A1.Add(5, 8));
	}

}
