package Assignemnt_set_2;

import java.util.ArrayList;

public class ArrayListIttaretor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ArrayList<String> list = new ArrayList<String>();
		list.add("apple");
		list.add("banana");
		list.add("orange");
		list.add("grapes");

		System.out.println("Iterating  all elements in the ArrayList:");
		for (int i = 0; i < list.size(); i++) {
			String element = list.get(i);
			System.out.println(element);
		}
	}

}
