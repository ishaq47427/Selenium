package assessment;


import java.util.Scanner;

public class sp_main {
	static Scanner scanner = new Scanner(System.in);
	public static void employee() {
		while(true) {
			System.out.println("Enter 1 to Add employee   : ");
			System.out.println("Enter 2 to View employee  : ");
			System.out.println("Enter 3 to Update employee: ");
			System.out.println("Enter 4 to Delete employee: ");
			System.out.println("Enter 0 to Exit: ");
			System.out.println();
			
			System.out.println("Enter Your Choice: ");
			int opt = scanner.nextInt();
			emp_crud emp = new emp_crud();
			
			switch(opt) {
			case 1: emp.addemp();
						break;
			case 2: emp.reademp();
						break;
			case 3: emp.updateemp();
						break;
			case 4: emp.deleteemp();
						break;
			case 0: System.exit(0);
						break;
			default : System.out.println("invalid Option Entry!!");
			}
		}
}
	public static void professor() {
		while(true) {
			System.out.println("Enter 1 to Add professor   : ");
			System.out.println("Enter 2 to View professor  : ");
			System.out.println("Enter 3 to Update professor: ");
			System.out.println("Enter 4 to Delete professor: ");
			System.out.println("Enter 0 to Exit: ");
			System.out.println();
			
			System.out.println("Enter Your Choice: ");
			int opt = scanner.nextInt();
			pro_crud pro = new pro_crud();
			
			switch(opt) {
			case 1: pro.addpro();
						break;
			case 2: pro.readpro();
						break;
			case 3: pro.updatepro();
						break;
			case 4: pro.deletepro();
						break;
			case 0: System.exit(0);
						break;
			default : System.out.println("invalid Option Entry!!");
			}
		}
		
}
	public static void department () {
		while(true) {
			System.out.println("Enter 1 to Add departrmet   : ");
			System.out.println("Enter 2 to View departrmet  : ");
			System.out.println("Enter 3 to Update departrmet: ");
			System.out.println("Enter 4 to Delete departrmet: ");
			System.out.println("Enter 0 to Exit: ");
			System.out.println();
			
			System.out.println("Enter Your Choice: ");
			int opt = scanner.nextInt();
			dept_crud dept = new dept_crud();
			
			switch(opt) {
			case 1: dept.adddept();
						break;
			case 2: dept.readdept();
						break;
			case 3: dept.updatedept();
						break;
			case 4: dept.deletedept();
						break;
			case 0: System.exit(0);
						break;
			default : System.out.println("invalid Option Entry!!");
			}
		}
}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		while(true) {
			System.out.println("Enter 1 for emoloyee: ");
			System.out.println("Enter 2 for professor : ");
			System.out.println("Enter 3 for department: ");
			System.out.println("Enter 0 to Exit: ");
			System.out.println();
			
			System.out.println("Enter Your Choice: ");
			int opt = scanner.nextInt();
			
			switch(opt) {
			case 1: employee();
						break;
			case 2: professor();
						break;
			case 3: department();
						break;
			case 0: System.exit(0);
						break;
			default : System.out.println("invalid Option Entry!!");
			}		
		}
	}
}