package Google.ExcelR.TestNG;

import org.testng.annotations.Test;

import com.beust.jcommander.Parameter;

public class ParameterPassing {
  @Test
  @Parameter
  public void ParameterTest(String browser) {
	  if(browser.equals("chrome")) {
		  System.out.println("open Chrome");
		  
		  
	  }
  }
}
