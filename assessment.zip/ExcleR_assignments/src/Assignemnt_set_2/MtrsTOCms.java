package Assignemnt_set_2;

public class MtrsTOCms {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double meters = 15.5;
		double centimeters;

		centimeters = meters * 100;

		System.out.printf("coverted " + meters + " into " + centimeters + " centimeters ");

	}

}
