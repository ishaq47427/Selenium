package Assignemnt_set_1;

public class Method_Overloading {
	
	public void printNumber(int num) {
		System.out.println("Integer number: " + num);
	}

	public void printNumber(double num) {
		System.out.println("Floating point number: " + num);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Method_Overloading obj = new Method_Overloading();
		obj.printNumber(5);
		obj.printNumber(5.5);
	}

}