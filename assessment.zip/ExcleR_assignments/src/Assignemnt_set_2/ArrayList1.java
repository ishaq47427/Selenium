package Assignemnt_set_2;

import java.util.ArrayList;

public class ArrayList1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ArrayList<String> colors = new ArrayList<String>();

		colors.add("red");
		colors.add("blue");
		colors.add("green");
		colors.add("yellow");

		System.out.println("Colors in the list:");

		System.out.println(colors);
	}
}
