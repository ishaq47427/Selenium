package Google.ExcelR;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ErrorMessage {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();

		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");

		driver.manage().window().maximize();

		WebElement userName = driver.findElement(By.xpath("//input[@name='username']"));
		userName.sendKeys("Admin");
		WebElement submit = driver.findElement(
				By.xpath("//button[@class=\"oxd-button oxd-button--medium oxd-button--main orangehrm-login-button\"]"));
		submit.click();

		String ExpectedError = "Required";

		String ErrorMsg = driver.findElement(By.xpath(
				"//span[@class=\"oxd-text oxd-text--span oxd-input-field-error-message oxd-input-group__message\"]"))
				.getText();

		System.out.println(ErrorMsg);
		if (ExpectedError.equalsIgnoreCase(ErrorMsg)) {
			System.out.println("thw message is mattichig");
		} else {
			System.out.println("is not matchig");
		}
	}

}
