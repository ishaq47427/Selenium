package Assignemnt_set_2;

public class smallArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] numbers = { 4, 3, 8, 1, 9, 6, 7, 2 };

		int smallest = Integer.MAX_VALUE;
		int secondSmallest = Integer.MAX_VALUE;
		for (int i = 0; i < numbers.length; i++) {
			if (numbers[i] < smallest) {
				secondSmallest = smallest;
				smallest = numbers[i];
			} else if (numbers[i] < secondSmallest) {
				secondSmallest = numbers[i];
			}
		}

		System.out.println("smallest  number: " + smallest);
		System.out.println("Second smallest number: " + secondSmallest);
	}

}
