package Google.ExcelR;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Chrome {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.facebook.com/");
		WebElement email = driver.findElement(By.id("email"));
		email.sendKeys("xyz@gmail.com");
		WebElement pass = driver.findElement(By.name("pass"));
		pass.sendKeys("ishaq");
		
		 //WebElement email = driver.findElement(By.className("inputtext _55r1 _6luy"));
		//WebElement email = driver.findElement(By.xpath("//input[@id=\"email\"]"));
		//WebElement email = driver.findElement(By.cssSelector("#email"));
		WebElement forPass = driver.findElement(By.linkText("Forgotten password?"));
		forPass.click();
		
	
	}

}
