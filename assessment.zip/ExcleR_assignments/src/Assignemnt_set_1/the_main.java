package Assignemnt_set_1;

public class the_main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee emp = new Employee();
        emp.name = "John Doe";
        emp.age = 30;
        emp.phoneNumber = "55522520";
        emp.address = "bangalore";
        emp.salary = 50000.0;
        emp.specialization = "Software Development";

        Manager mgr = new Manager();
        mgr.name = "Jane Smith";
        mgr.age = 40;
        mgr.phoneNumber = "55516544";
        mgr.address = "hydrabad";
        mgr.salary = 75000.0;
        mgr.department = "Engineering";

        System.out.println("Employee:");
        System.out.println("Name: " + emp.name);
        System.out.println("Age: " + emp.age);
        System.out.println("Phone Number: " + emp.phoneNumber);
        System.out.println("Address: " + emp.address);
        emp.printSalary();
        System.out.println("Specialization: " + emp.specialization);

        System.out.println();

        System.out.println("Manager:");
        System.out.println("Name: " + mgr.name);
        System.out.println("Age: " + mgr.age);
        System.out.println("Phone Number: " + mgr.phoneNumber);
        System.out.println("Address: " + mgr.address);
        mgr.printSalary();
        System.out.println("Department: " + mgr.department);
	}

}