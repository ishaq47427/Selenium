package Assignemnt_set_1;

public class Main_class {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Square square = new Square();
        square.display_shape(); 
        square.display_rect(); 
        square.display_Square(); 

	}

}
