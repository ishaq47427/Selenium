//1.	Sort Program in Java
package assigments;

public class Sort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sort[] = { 9, 8, 7, 6, 5, 4, 3, 2, 1 };
		int temp = 0;

		for (int i = 0; i < sort.length; i++) {
			
			for (int j = i + 1; j < sort.length; j++) {
				
				
				if (sort[j] < sort[i]) {
					// Swapping
					temp = sort[i];
					sort[i] = sort[j];
					sort[j] = temp;
				}
			}
			System.out.print(sort[i] + " ");
		}

	}
}