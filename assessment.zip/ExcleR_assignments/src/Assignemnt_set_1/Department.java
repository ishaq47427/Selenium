package Assignemnt_set_1;

class Manager extends member {
    String department;
}
