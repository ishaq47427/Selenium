package Google.ExcelR;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class singleRadio {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://jqueryui.com/checkboxradio/");
		WebElement frame   = driver.findElement(By.xpath("//iframe[@class=\"demo-frame\"]"));
		
		driver.switchTo().frame(frame);
		
		WebElement checkBox   = driver.findElement(By.xpath("(//label[@class=\"ui-checkboxradio-label ui-corner-all ui-button ui-widget\"])[1]"));
		checkBox.click();
		WebElement checkBox2   = driver.findElement(By.xpath("(//label[@class=\"ui-checkboxradio-label ui-corner-all ui-button ui-widget\"])[2]"));
		checkBox2.click();
	}

}
