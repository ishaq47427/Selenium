package assigments;

public class NonRepeatingChar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = "Morning";
		for (int i = 0; i < s.length(); i++) {

			if (s.indexOf(s.charAt(i), s.indexOf(s.charAt(i))  ) == 1) {
				System.out.println("repeating characters are " + s.charAt(i));
				break;

			}
		}
		return;
	}
}