package Assignemnt_set_1;

public class reverse_String {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "java string";
		String rev = "";
		System.out.println("the orignal string is: " + str);
		for (int i = str.length() - 1; i >= 0; i--) {
			rev = rev + str.charAt(i);
		}
		System.out.println("the reversed string is: " + rev);
	}

}
