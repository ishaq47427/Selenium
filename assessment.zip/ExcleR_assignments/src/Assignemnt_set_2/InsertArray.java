package Assignemnt_set_2;

import java.util.ArrayList;

public class InsertArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 ArrayList<String> list = new ArrayList<String>();
	        list.add("apple");
	        list.add("banana");
	        list.add("orange");

	        // insert a new element at the first position
	        String newElement = "pear";
	        list.add(0, newElement);

	        // print out the updated list
	        System.out.println("Updated ArrayList:");
	        
	            System.out.println(list);
	        }
	}

