package Pages;

public class Product {

}
