package Test_NG;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

import org.testng.annotations.BeforeClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;

public class ContactUsPageTest {
	WebDriver driver1;
	
  @Test
  public void f() {
	  driver1.get("https://phptravels.org/contact.php");
	  driver1.findElement(By.id("inputName")).sendKeys("ish");
	  driver1.findElement(By.id("inputEmail")).sendKeys("ish@gmail.com");
	  driver1.findElement(By.id("inputSubject")).sendKeys("having problem");
	  driver1.findElement(By.name("message")).sendKeys("hi have a problem solve");
  }
  @BeforeClass
  public void openContactUsPage() {
	  WebDriverManager.chromedriver().setup();
		driver1 = new ChromeDriver();
  }

  @AfterClass
  public void closeContactUsPage() {
  }

}
